# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function


def _install_fury_servname2_fallback():
    """Register the optional skin converter before any XtreamNew screen opens."""
    try:
        __import__("Components.Converter.furyServName2", fromlist=["furyServName2"])
        return
    except Exception:
        pass
    try:
        import sys
        import types
        from Components.Converter.Converter import Converter
        from Components.Element import cached

        class furyServName2(Converter):
            @cached
            def getText(self):
                source = getattr(self, "source", None)
                for attr in ("text", "serviceName", "name"):
                    try:
                        value = getattr(source, attr, "")
                        if callable(value):
                            value = value()
                        if value:
                            return str(value)
                    except Exception:
                        pass
                try:
                    service = getattr(source, "service", None)
                    info = service and service.info()
                    ref = getattr(source, "serviceref", None)
                    if info is not None:
                        try:
                            name = info.getName(ref) if ref is not None else info.getName()
                            if name:
                                return str(name).replace("\\xc2\\x86", "").replace("\\xc2\\x87", "")
                        except Exception:
                            pass
                except Exception:
                    pass
                return ""

            text = property(getText)

        module_name = "Components.Converter.furyServName2"
        module = types.ModuleType(module_name)
        module.furyServName2 = furyServName2
        sys.modules[module_name] = module
        try:
            import Components.Converter as converter_package
            setattr(converter_package, "furyServName2", module)
        except Exception:
            pass
    except Exception:
        pass



def _install_aglare_routeinfo_fallback():
    """Register the optional AglareRouteInfo converter used by some skins.

    A missing skin converter must never abort returning from an XtreamNew child
    screen.  Keep the fallback deliberately read-only and side-effect free.
    """
    try:
        __import__("Components.Converter.AglareRouteInfo", fromlist=["AglareRouteInfo"])
        return
    except Exception:
        pass
    try:
        import sys
        import types
        from Components.Converter.Converter import Converter
        from Components.Element import cached

        class AglareRouteInfo(Converter):
            @cached
            def getText(self):
                source = getattr(self, "source", None)
                for attr in ("text", "routeInfo", "value"):
                    try:
                        value = getattr(source, attr, "")
                        if callable(value):
                            value = value()
                        if value not in (None, ""):
                            return str(value)
                    except Exception:
                        pass
                return ""

            text = property(getText)

            @cached
            def getBoolean(self):
                return False

            boolean = property(getBoolean)

        module_name = "Components.Converter.AglareRouteInfo"
        module = types.ModuleType(module_name)
        module.AglareRouteInfo = AglareRouteInfo
        sys.modules[module_name] = module
        try:
            import Components.Converter as converter_package
            setattr(converter_package, "AglareRouteInfo", module)
        except Exception:
            pass
    except Exception:
        pass


_install_fury_servname2_fallback()
_install_aglare_routeinfo_fallback()
