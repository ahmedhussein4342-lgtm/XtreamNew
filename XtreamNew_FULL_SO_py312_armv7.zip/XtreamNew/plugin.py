# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import os
import time


def _remove_obsolete_abi_so_files():
    """Remove old ABI-tagged SO files when the normalized module.so exists.

    This runs before importing any compiled XtreamNew module.  It is also the
    one-time migration path from packages that used names such as
    module.cpython-314-arm-linux-gnueabihf.so to the normalized module.so.
    """
    try:
        plugin_root = os.path.dirname(os.path.abspath(__file__))
        for root, dirs, files in os.walk(plugin_root):
            file_set = set(files)
            for name in list(files):
                marker = ".cpython-"
                if marker not in name or not name.endswith(".so"):
                    continue
                short_name = name.split(marker, 1)[0] + ".so"
                if short_name not in file_set:
                    continue
                old_path = os.path.join(root, name)
                try:
                    os.remove(old_path)
                except Exception:
                    pass

            # When a normalized module.so exists, remove matching source and
            # bytecode files so only the compiled release module remains.
            for so_name in list(files):
                if not so_name.endswith(".so") or ".cpython-" in so_name:
                    continue
                module_name = so_name[:-3]
                for sibling in (module_name + ".py", module_name + ".pyc"):
                    sibling_path = os.path.join(root, sibling)
                    if os.path.isfile(sibling_path):
                        try:
                            os.remove(sibling_path)
                        except Exception:
                            pass
                cache_dir = os.path.join(root, "__pycache__")
                if os.path.isdir(cache_dir):
                    try:
                        for cached_name in os.listdir(cache_dir):
                            if (cached_name == module_name + ".pyc" or
                                    (cached_name.startswith(module_name + ".") and cached_name.endswith(".pyc"))):
                                try:
                                    os.remove(os.path.join(cache_dir, cached_name))
                                except Exception:
                                    pass
                        if not os.listdir(cache_dir):
                            os.rmdir(cache_dir)
                    except Exception:
                        pass
    except Exception:
        pass


_remove_obsolete_abi_so_files()


from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from enigma import eTimer

try:
    from .font_support import register_plugin_fonts
    register_plugin_fonts()
except Exception:
    pass

from .mainmenu import XtreamMainMenu
from .store import getSetting, getActivePlaylist, getDataDir, ensureDir
from .xtream_api import XtreamAPI
try:
    from .webserver import start_web_server
except Exception:
    start_web_server = None

def _auto_state_file():
    try:
        root = str(getDataDir() or "/etc/enigma2/xtreamnew")
    except Exception:
        root = "/etc/enigma2/xtreamnew"
    return os.path.join(root, "auto_update_state.txt")


AUTO_UPDATER = None
UPDATE_NOTICE_TIMER = None


def _read_last_run():
    try:
        path = _auto_state_file()
        if os.path.exists(path):
            f = open(path, "r")
            txt = f.read().strip()
            f.close()
            return int(txt or "0")
    except Exception:
        pass
    return 0


def _write_last_run(ts):
    try:
        path = _auto_state_file()
        ensureDir(os.path.dirname(path))
        f = open(path, "w")
        f.write(str(int(ts)))
        f.close()
    except Exception:
        pass


def _clear_dir(path):
    try:
        if not path or not os.path.exists(path):
            return 0
        removed = 0
        for name in os.listdir(path):
            fp = os.path.join(path, name)
            try:
                if os.path.isfile(fp):
                    os.remove(fp)
                    removed += 1
            except Exception:
                pass
        return removed
    except Exception:
        return 0


def clear_vod_series_cache():
    total = 0
    for base in ["/media/hdd/XtreamNew/cache", "/tmp/XtreamNew/cache"]:
        total += _clear_dir(os.path.join(base, "vod_categories"))
        total += _clear_dir(os.path.join(base, "series_categories"))
    return total


def run_background_update():
    active = getActivePlaylist()
    if not active:
        return False, "No active playlist", 0

    removed = clear_vod_series_cache()

    try:
        api = XtreamAPI(
            active.get("host", ""),
            active.get("username", ""),
            active.get("password", ""),
            active.get("output", "ts")
        )
        ok, msg = api.downloadAndBuildLocalEPG()
        if ok:
            _write_last_run(time.time())
            return True, "EPG updated", removed
        return False, str(msg), removed
    except Exception as e:
        return False, str(e), removed


class XtreamAutoUpdater(object):
    def __init__(self):
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.tick)
        except Exception:
            try:
                self.timer.timeout.connect(self.tick)
            except Exception:
                pass
        self.start()

    def start(self):
        try:
            self.timer.start(60000, True)
        except Exception:
            pass

    def tick(self):
        try:
            enabled = bool(getSetting("epg_auto_update", False))
            interval_hours = int(getSetting("epg_auto_interval_hours", 12) or 12)
        except Exception:
            enabled = False
            interval_hours = 12

        if enabled:
            last_run = _read_last_run()
            now = int(time.time())
            interval_seconds = max(1, interval_hours) * 3600
            if (now - last_run) >= interval_seconds:
                run_background_update()


def _check_online_update_on_open(session):
    global UPDATE_NOTICE_TIMER
    try:
        from .online_update import notify_update_available
    except Exception:
        try:
            from Plugins.Extensions.XtreamNew.online_update import notify_update_available
        except Exception:
            notify_update_available = None

    if notify_update_available is None:
        return

    def _run():
        global UPDATE_NOTICE_TIMER
        try:
            notify_update_available(session)
        except Exception:
            pass
        UPDATE_NOTICE_TIMER = None

    try:
        UPDATE_NOTICE_TIMER = eTimer()
        try:
            UPDATE_NOTICE_TIMER.callback.append(_run)
        except Exception:
            UPDATE_NOTICE_TIMER.timeout.connect(_run)
        UPDATE_NOTICE_TIMER.start(1200, True)
    except Exception:
        UPDATE_NOTICE_TIMER = None


def main(session, **kwargs):
    try:
        session.open(XtreamMainMenu)
        _check_online_update_on_open(session)
    except Exception as e:
        session.open(MessageBox, "XtreamNew error:\n%s" % str(e), MessageBox.TYPE_ERROR)


def onSessionStart(reason, session=None, **kwargs):
    global AUTO_UPDATER
    if session is None:
        return
    if AUTO_UPDATER is None:
        AUTO_UPDATER = XtreamAutoUpdater()
    try:
        if start_web_server is not None:
            start_web_server(7090)
    except Exception:
        pass


def mainMenuHook(menuid, **kwargs):
    """Optionally expose XtreamNew in Enigma2's native Main Menu."""
    try:
        if str(menuid or "") == "mainmenu" and bool(getSetting("show_in_main_menu", False)):
            return [("XtreamNew", main, "xtreamnew_mainmenu", 50)]
    except Exception:
        pass
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="XtreamNew",
            description="Xtream IPTV Player",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=onSessionStart
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_MENU,
            fnc=mainMenuHook
        )
    ]
