# -*- coding: utf-8 -*-
try:
    from ..cinematic_view import CinematicItemsScreen
except Exception:
    from Plugins.Extensions.XtreamNew.cinematic_view import CinematicItemsScreen

class CleanSeriesCinematicItemsScreen(CinematicItemsScreen):
    def __init__(self, session, category=None, *args, **kwargs):
        CinematicItemsScreen.__init__(self, session, category, mode="series")
