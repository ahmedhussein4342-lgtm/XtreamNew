# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

"""
XtreamNew VOD clean entry point.

Home Grid setting opens categories first.
The selected category opens the independent horizontal items screen.
No old VOD logic is kept here.
"""

from Screens.Screen import Screen

try:
    from .store import getSetting
except Exception:
    def getSetting(key, default=None):
        return default


VOD_LAYOUT_REGISTRY = {
    # Keep the single visible setup option name, but route it to categories first.
    "home_grid": "Plugins.Extensions.XtreamNew.vod_layouts.categories.CleanVodCategoriesScreen",
}


def _safe_layout_key(value):
    value = str(value or "home_grid").strip().lower()
    if value not in VOD_LAYOUT_REGISTRY:
        value = "home_grid"
    return value


def _load_class(path):
    module_name, class_name = path.rsplit(".", 1)
    try:
        module = __import__(module_name, globals(), locals(), [class_name], 0)
    except ImportError:
        if module_name.startswith("Plugins.Extensions.XtreamNew."):
            module_name = module_name.replace("Plugins.Extensions.XtreamNew.", "", 1)
            module = __import__(module_name, globals(), locals(), [class_name], 0)
        else:
            raise
    return getattr(module, class_name)


class XtreamVodScreen(Screen):
    """Router only: VOD always starts from the standalone categories screen."""

    def __new__(cls, session, *args, **kwargs):
        layout_key = _safe_layout_key(getSetting("vod_layout_style", "home_grid"))
        screen_class = _load_class(VOD_LAYOUT_REGISTRY[layout_key])
        return screen_class(session, *args, **kwargs)
