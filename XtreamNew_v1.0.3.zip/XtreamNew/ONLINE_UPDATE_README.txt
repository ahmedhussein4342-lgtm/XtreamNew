XtreamNew Online Update

GitHub:
https://raw.githubusercontent.com/ahmedhussein4342-lgtm/XtreamNew/main/version.json
https://raw.githubusercontent.com/ahmedhussein4342-lgtm/XtreamNew/main/XtreamNew.zip

In plugin:
Settings -> YELLOW Online Update

version.json example:
{
  "plugin": "XtreamNew",
  "version": "1.0.1",
  "build": "2026.07.04",
  "force": false,
  "zip": "https://raw.githubusercontent.com/ahmedhussein4342-lgtm/XtreamNew/main/XtreamNew.zip",
  "message": "New fixes available."
}
